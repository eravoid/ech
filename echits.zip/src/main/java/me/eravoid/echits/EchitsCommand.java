package me.eravoid.echits;

import org.bukkit.command.*;

public class EchitsCommand implements CommandExecutor {
    private final Echits plugin;
    public EchitsCommand(Echits plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (a.length == 1 && a[0].equalsIgnoreCase("reload")) {
            plugin.reloadConfig();
            s.sendMessage("§aConfig reloaded!");
            return true;
        }
        s.sendMessage("§e/echits reload");
        return true;
    }
}
