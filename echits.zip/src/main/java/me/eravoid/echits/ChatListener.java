package me.eravoid.echits;

import org.bukkit.event.Listener;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.entity.Player;
import java.util.*;

public class ChatListener implements Listener {
    private final Echits plugin;
    private final Map<UUID, Long> cooldown = new HashMap<>();

    public ChatListener(Echits plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onChat(AsyncPlayerChatEvent e) {
        Player p = e.getPlayer();
        UUID id = p.getUniqueId();
        long now = System.currentTimeMillis();
        int cd = plugin.getConfig().getInt("chat.message-cooldown");

        if (cooldown.containsKey(id)) {
            long last = cooldown.get(id);
            long diff = (now - last) / 1000;
            if (diff < cd) {
                e.setCancelled(true);
                p.sendMessage("§cPlease wait " + (cd - diff) + "s");
                return;
            }
        }
        cooldown.put(id, now);
    }
}
