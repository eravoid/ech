package me.eravoid.echits;

import org.bukkit.plugin.java.JavaPlugin;

public class Echits extends JavaPlugin {
    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(new ChatListener(this), this);
        getCommand("echits").setExecutor(new EchitsCommand(this));
    }
}
